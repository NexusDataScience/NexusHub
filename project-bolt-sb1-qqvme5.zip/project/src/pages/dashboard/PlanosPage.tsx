import React, { useState } from 'react';
import { Edit2, Check, X, Plus, Trash2 } from 'lucide-react';
import { Button } from '../../components/ui/Button';
import type { Plan } from '../../types/plans';

export const PlanosPage: React.FC = () => {
  const [plans, setPlans] = useState<Plan[]>([
    {
      id: 1,
      name: 'Iniciante (Básico)',
      description: 'Ideal para agências iniciantes',
      price: 299,
      features: [
        'Controle de UTM',
        'Controle de Campanhas',
        '3 Relatórios por mês',
      ],
      maxClients: 3,
      maxReports: 3,
    },
    {
      id: 2,
      name: 'Agência',
      description: 'Para agências em crescimento',
      price: 499,
      features: [
        'Controle de UTM',
        'Controle de Campanhas',
        '10 Relatórios por mês',
        'Suporte prioritário',
      ],
      maxClients: 5,
      maxReports: 10,
      recommended: true,
    },
    {
      id: 3,
      name: 'Super Agência',
      description: 'Para agências de grande porte',
      price: 999,
      features: [
        'Controle de UTM',
        'Controle de Campanhas',
        'Relatórios ilimitados',
        'Suporte 24/7',
        'API access',
      ],
      maxClients: 10,
      maxReports: 'unlimited',
    },
  ]);

  const [editingPlan, setEditingPlan] = useState<number | null>(null);
  const [editForm, setEditForm] = useState<Plan | null>(null);
  const [showFeatureInput, setShowFeatureInput] = useState<number | null>(null);
  const [newFeature, setNewFeature] = useState('');

  const handleEdit = (plan: Plan) => {
    setEditingPlan(plan.id);
    setEditForm({ ...plan });
  };

  const handleSave = () => {
    if (editForm) {
      setPlans(plans.map(p => p.id === editForm.id ? editForm : p));
      setEditingPlan(null);
      setEditForm(null);
    }
  };

  const handleAddFeature = (planId: number) => {
    if (newFeature.trim() && editForm) {
      setEditForm({
        ...editForm,
        features: [...editForm.features, newFeature.trim()]
      });
      setNewFeature('');
      setShowFeatureInput(null);
    }
  };

  const handleRemoveFeature = (index: number) => {
    if (editForm) {
      setEditForm({
        ...editForm,
        features: editForm.features.filter((_, i) => i !== index)
      });
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-semibold text-gray-900">Planos</h1>
          <p className="text-sm text-gray-500 mt-1">Gerencie os planos disponíveis para as agências</p>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        {plans.map((plan) => (
          <div
            key={plan.id}
            className={`bg-white rounded-lg shadow-sm p-6 border-2 ${
              plan.recommended ? 'border-blue-500' : 'border-transparent'
            }`}
          >
            {editingPlan === plan.id ? (
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Nome do Plano</label>
                  <input
                    type="text"
                    className="w-full text-xl font-semibold p-2 border rounded"
                    value={editForm?.name}
                    onChange={(e) => setEditForm(prev => prev ? { ...prev, name: e.target.value } : null)}
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Preço Mensal</label>
                  <div className="flex items-center space-x-2">
                    <span className="text-2xl font-bold">R$</span>
                    <input
                      type="number"
                      className="w-24 text-2xl font-bold p-2 border rounded"
                      value={editForm?.price}
                      onChange={(e) => setEditForm(prev => prev ? { ...prev, price: Number(e.target.value) } : null)}
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Limite de Clientes</label>
                  <input
                    type="number"
                    className="w-full p-2 border rounded"
                    value={editForm?.maxClients}
                    onChange={(e) => setEditForm(prev => prev ? { ...prev, maxClients: Number(e.target.value) } : null)}
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Recursos Incluídos</label>
                  <ul className="space-y-2">
                    {editForm?.features.map((feature, index) => (
                      <li key={index} className="flex items-center justify-between">
                        <span>{feature}</span>
                        <button
                          onClick={() => handleRemoveFeature(index)}
                          className="text-red-500 hover:text-red-700"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </li>
                    ))}
                  </ul>
                  
                  {showFeatureInput === plan.id ? (
                    <div className="mt-2 flex items-center space-x-2">
                      <input
                        type="text"
                        className="flex-1 p-2 border rounded"
                        value={newFeature}
                        onChange={(e) => setNewFeature(e.target.value)}
                        placeholder="Novo recurso..."
                      />
                      <Button size="sm" onClick={() => handleAddFeature(plan.id)}>
                        <Plus className="w-4 h-4" />
                      </Button>
                    </div>
                  ) : (
                    <Button
                      variant="outline"
                      size="sm"
                      className="mt-2"
                      onClick={() => setShowFeatureInput(plan.id)}
                    >
                      <Plus className="w-4 h-4 mr-1" />
                      Adicionar Recurso
                    </Button>
                  )}
                </div>

                <div className="flex justify-end space-x-2">
                  <Button size="sm" onClick={handleSave}>
                    <Check className="w-4 h-4 mr-1" />
                    Salvar
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => {
                      setEditingPlan(null);
                      setEditForm(null);
                      setShowFeatureInput(null);
                    }}
                  >
                    <X className="w-4 h-4 mr-1" />
                    Cancelar
                  </Button>
                </div>
              </div>
            ) : (
              <>
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="text-xl font-semibold text-gray-900">{plan.name}</h3>
                    <p className="text-sm text-gray-500 mt-1">{plan.description}</p>
                  </div>
                  <Button variant="outline" size="sm" onClick={() => handleEdit(plan)}>
                    <Edit2 className="w-4 h-4" />
                  </Button>
                </div>
                <div className="mt-4">
                  <span className="text-3xl font-bold">R${plan.price}</span>
                  <span className="text-gray-500">/mês</span>
                </div>
                <ul className="mt-6 space-y-4">
                  {plan.features.map((feature, index) => (
                    <li key={index} className="flex items-center">
                      <Check className="w-5 h-5 text-green-500 mr-2" />
                      {feature}
                    </li>
                  ))}
                </ul>
                {plan.recommended && (
                  <div className="mt-4">
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                      Recomendado
                    </span>
                  </div>
                )}
              </>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};