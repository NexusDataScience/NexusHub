import React from 'react';
import { Mail, Bell, Shield, Database } from 'lucide-react';
import { Button } from '../../components/ui/Button';

export const ConfiguracoesPage: React.FC = () => {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold text-gray-900">Configurações</h1>
        <p className="text-sm text-gray-500 mt-1">
          Gerencie as configurações do sistema
        </p>
      </div>

      {/* Email Settings */}
      <div className="bg-white shadow-sm rounded-lg p-6">
        <div className="flex items-center mb-4">
          <Mail className="w-5 h-5 text-gray-400 mr-2" />
          <h2 className="text-lg font-medium text-gray-900">Configurações de Email</h2>
        </div>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Email do Sistema
            </label>
            <input
              type="email"
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              value="sistema@hub.nexus.com.br"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Servidor SMTP
            </label>
            <input
              type="text"
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              value="smtp.hub.nexus.com.br"
            />
          </div>
        </div>
      </div>

      {/* Notification Settings */}
      <div className="bg-white shadow-sm rounded-lg p-6">
        <div className="flex items-center mb-4">
          <Bell className="w-5 h-5 text-gray-400 mr-2" />
          <h2 className="text-lg font-medium text-gray-900">Notificações</h2>
        </div>
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-medium text-gray-900">Notificações de Pagamento</h3>
              <p className="text-sm text-gray-500">Receba alertas sobre pagamentos pendentes</p>
            </div>
            <div className="flex items-center">
              <input
                type="checkbox"
                className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                defaultChecked
              />
            </div>
          </div>
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-medium text-gray-900">Notificações de Novos Cadastros</h3>
              <p className="text-sm text-gray-500">Receba alertas sobre novas agências</p>
            </div>
            <div className="flex items-center">
              <input
                type="checkbox"
                className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                defaultChecked
              />
            </div>
          </div>
        </div>
      </div>

      {/* Security Settings */}
      <div className="bg-white shadow-sm rounded-lg p-6">
        <div className="flex items-center mb-4">
          <Shield className="w-5 h-5 text-gray-400 mr-2" />
          <h2 className="text-lg font-medium text-gray-900">Segurança</h2>
        </div>
        <div className="space-y-4">
          <div>
            <h3 className="text-sm font-medium text-gray-900">Autenticação em Duas Etapas</h3>
            <p className="text-sm text-gray-500 mb-2">Adicione uma camada extra de segurança</p>
            <Button variant="outline">Configurar 2FA</Button>
          </div>
          <div>
            <h3 className="text-sm font-medium text-gray-900">Política de Senhas</h3>
            <p className="text-sm text-gray-500 mb-2">Configure os requisitos mínimos de senha</p>
            <Button variant="outline">Gerenciar Política</Button>
          </div>
        </div>
      </div>

      {/* Backup Settings */}
      <div className="bg-white shadow-sm rounded-lg p-6">
        <div className="flex items-center mb-4">
          <Database className="w-5 h-5 text-gray-400 mr-2" />
          <h2 className="text-lg font-medium text-gray-900">Backup</h2>
        </div>
        <div className="space-y-4">
          <div>
            <h3 className="text-sm font-medium text-gray-900">Backup Automático</h3>
            <p className="text-sm text-gray-500 mb-2">Configure a frequência dos backups</p>
            <select className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
              <option>Diário</option>
              <option>Semanal</option>
              <option>Mensal</option>
            </select>
          </div>
          <div className="flex space-x-4">
            <Button variant="outline">Fazer Backup Manual</Button>
            <Button variant="outline">Restaurar Backup</Button>
          </div>
        </div>
      </div>
    </div>
  );
};