import React, { useState } from 'react';
import { useParams } from 'react-router-dom';
import { Calendar, CreditCard, AlertCircle, Users, BarChart2 } from 'lucide-react';
import { Button } from '../../components/ui/Button';
import type { Agency } from '../../types/agency';
import type { Client } from '../../types/client';

export const AgencyDetailsPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  
  // Mock agency data - replace with actual data fetching
  const agency: Agency = {
    id: '1',
    name: 'Digital Marketing Pro',
    website: 'https://digitalmarketingpro.com.br',
    responsible: 'João Silva',
    username: 'dmpro',
    email: 'joao@digitalmarketingpro.com.br',
    whatsapp: '(11) 98765-4321',
    plan: 3,
    createdAt: new Date('2024-01-15'),
    isActive: true,
    lastPaymentDate: new Date('2024-03-01'),
    nextPaymentDate: new Date('2024-04-01')
  };

  // Mock clients data
  const [clients] = useState<Client[]>([
    {
      id: '1',
      agencyId: '1',
      name: 'Loja Virtual Express',
      email: 'contato@lojavirtualexpress.com.br',
      phone: '(11) 97777-8888',
      status: 'active',
      createdAt: new Date('2024-02-01'),
      campaigns: {
        google: 3,
        meta: 2
      }
    },
    {
      id: '2',
      agencyId: '1',
      name: 'Restaurante Sabor & Arte',
      email: 'marketing@saborarte.com.br',
      phone: '(11) 96666-7777',
      status: 'active',
      createdAt: new Date('2024-02-15'),
      campaigns: {
        google: 1,
        meta: 1
      }
    }
  ]);

  const payments = [
    {
      id: '1',
      date: new Date('2024-03-01'),
      amount: 999,
      status: 'paid' as const
    },
    {
      id: '2',
      date: new Date('2024-02-01'),
      amount: 999,
      status: 'paid' as const
    }
  ];

  return (
    <div className="space-y-6">
      {/* Agency Header */}
      <div className="bg-white shadow-sm rounded-lg p-6">
        <div className="flex justify-between items-start">
          <div>
            <h1 className="text-2xl font-semibold text-gray-900">{agency.name}</h1>
            <p className="text-sm text-gray-500 mt-1">{agency.website}</p>
          </div>
          <div className={`px-3 py-1 rounded-full text-sm font-medium ${
            agency.isActive ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
          }`}>
            {agency.isActive ? 'Ativo' : 'Inativo'}
          </div>
        </div>

        <div className="mt-6 grid grid-cols-1 gap-6 sm:grid-cols-2">
          <div>
            <h2 className="text-lg font-medium text-gray-900 mb-4">Informações de Contato</h2>
            <dl className="space-y-4">
              <div>
                <dt className="text-sm font-medium text-gray-500">Responsável</dt>
                <dd className="mt-1 text-sm text-gray-900">{agency.responsible}</dd>
              </div>
              <div>
                <dt className="text-sm font-medium text-gray-500">Email</dt>
                <dd className="mt-1 text-sm text-gray-900">{agency.email}</dd>
              </div>
              <div>
                <dt className="text-sm font-medium text-gray-500">WhatsApp</dt>
                <dd className="mt-1 text-sm text-gray-900">{agency.whatsapp}</dd>
              </div>
            </dl>
          </div>

          <div>
            <h2 className="text-lg font-medium text-gray-900 mb-4">Plano e Pagamentos</h2>
            <div className="bg-gray-50 p-4 rounded-lg">
              <div className="flex justify-between items-center mb-4">
                <span className="text-sm font-medium text-gray-900">Super Agência</span>
                <span className="text-sm text-gray-500">R$ 999/mês</span>
              </div>
              <div className="space-y-2">
                <div className="flex items-center text-sm text-gray-600">
                  <Calendar className="w-4 h-4 mr-2" />
                  Próximo pagamento: {agency.nextPaymentDate?.toLocaleDateString('pt-BR')}
                </div>
                <div className="flex items-center text-sm text-gray-600">
                  <Users className="w-4 h-4 mr-2" />
                  10 clientes permitidos
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Clients Section */}
      <div className="bg-white shadow-sm rounded-lg p-6">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-lg font-medium text-gray-900">Clientes</h2>
          <Button>
            <Users className="w-4 h-4 mr-2" />
            Novo Cliente
          </Button>
        </div>

        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Cliente
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Contato
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Campanhas Ativas
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Ações
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {clients.map((client) => (
                <tr key={client.id}>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900">{client.name}</div>
                    <div className="text-sm text-gray-500">Cliente desde: {client.createdAt.toLocaleDateString('pt-BR')}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900">{client.email}</div>
                    <div className="text-sm text-gray-500">{client.phone}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex space-x-4">
                      <div className="flex items-center">
                        <BarChart2 className="w-4 h-4 text-blue-500 mr-1" />
                        <span className="text-sm text-gray-900">Google: {client.campaigns.google}</span>
                      </div>
                      <div className="flex items-center">
                        <BarChart2 className="w-4 h-4 text-blue-500 mr-1" />
                        <span className="text-sm text-gray-900">Meta: {client.campaigns.meta}</span>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                      client.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                    }`}>
                      {client.status === 'active' ? 'Ativo' : 'Inativo'}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <Button variant="outline" size="sm">
                      Gerenciar
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Payment History */}
      <div className="bg-white shadow-sm rounded-lg p-6">
        <h2 className="text-lg font-medium text-gray-900 mb-4">Histórico de Pagamentos</h2>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Data
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Valor
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {payments.map((payment) => (
                <tr key={payment.id}>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center text-sm text-gray-900">
                      <Calendar className="w-4 h-4 text-gray-400 mr-2" />
                      {payment.date.toLocaleDateString('pt-BR')}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center text-sm text-gray-900">
                      <CreditCard className="w-4 h-4 text-gray-400 mr-2" />
                      R$ {payment.amount}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                      Pago
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Access Control */}
      <div className="bg-white shadow-sm rounded-lg p-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-medium text-gray-900">Controle de Acesso</h2>
            <p className="text-sm text-gray-500 mt-1">Gerencie o acesso da agência ao sistema</p>
          </div>
          <Button variant="outline" className="text-red-600 border-red-600 hover:bg-red-50">
            <AlertCircle className="w-4 h-4 mr-2" />
            {agency.isActive ? 'Suspender Acesso' : 'Reativar Acesso'}
          </Button>
        </div>
      </div>
    </div>
  );
};