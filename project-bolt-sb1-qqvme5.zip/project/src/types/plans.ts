export interface Plan {
  id: number;
  name: string;
  description: string;
  price: number;
  features: string[];
  maxClients: number;
  maxReports: number | 'unlimited';
  recommended?: boolean;
}

export type PlanId = 1 | 2 | 3;