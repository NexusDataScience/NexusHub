export interface Client {
  id: string;
  agencyId: string;
  name: string;
  email: string;
  phone: string;
  status: 'active' | 'inactive';
  createdAt: Date;
  campaigns: {
    google: number;
    meta: number;
  };
}

export type ClientFormData = Omit<Client, 'id' | 'createdAt' | 'agencyId'>;