import React from 'react';
import { Building2, Edit2, Trash2, ExternalLink, Calendar } from 'lucide-react';
import { Button } from '../../components/ui/Button';
import { useNavigate } from 'react-router-dom';
import type { Agency } from '../../types/agency';

export const AgenciasPage: React.FC = () => {
  const navigate = useNavigate();
  // Mock data with 3 example agencies
  const agencies: Agency[] = [
    {
      id: '1',
      name: 'Digital Marketing Pro',
      website: 'https://digitalmarketingpro.com.br',
      responsible: 'João Silva',
      username: 'dmpro',
      email: 'joao@digitalmarketingpro.com.br',
      whatsapp: '(11) 98765-4321',
      plan: 3,
      createdAt: new Date('2024-01-15'),
      isActive: true,
      lastPaymentDate: new Date('2024-03-01'),
      nextPaymentDate: new Date('2024-04-01')
    },
    {
      id: '2',
      name: 'Agência Impulso',
      website: 'https://agenciaimpulso.com.br',
      responsible: 'Maria Santos',
      username: 'impulso',
      email: 'maria@agenciaimpulso.com.br',
      whatsapp: '(21) 98765-4321',
      plan: 2,
      createdAt: new Date('2024-02-01'),
      isActive: false,
      lastPaymentDate: new Date('2024-02-01'),
      nextPaymentDate: new Date('2024-03-01')
    },
    {
      id: '3',
      name: 'Marketing Digital Express',
      website: 'https://mdexpress.com.br',
      responsible: 'Pedro Oliveira',
      username: 'mdexpress',
      email: 'pedro@mdexpress.com.br',
      whatsapp: '(31) 98765-4321',
      plan: 1,
      createdAt: new Date('2024-03-01'),
      isActive: true,
      lastPaymentDate: new Date('2024-03-01'),
      nextPaymentDate: new Date('2024-04-01')
    }
  ];

  const getPlanLabel = (plan: number) => {
    switch (plan) {
      case 1:
        return 'Iniciante';
      case 2:
        return 'Agência';
      case 3:
        return 'Super Agência';
      default:
        return 'Desconhecido';
    }
  };

  const getPlanColor = (plan: number) => {
    switch (plan) {
      case 1:
        return 'bg-gray-100 text-gray-800';
      case 2:
        return 'bg-blue-100 text-blue-800';
      case 3:
        return 'bg-green-100 text-green-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const handleToggleAccess = (agencyId: string) => {
    // In a real application, this would update the database
    console.log('Toggle access for agency:', agencyId);
  };

  const handleEditAgency = (agencyId: string) => {
    navigate(`/dashboard/agencias/${agencyId}`);
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-semibold text-gray-900">Agências</h1>
          <p className="text-sm text-gray-500 mt-1">
            Gerencie as agências cadastradas no sistema
          </p>
        </div>
        <Button onClick={() => navigate('/dashboard/agencias/nova')}>
          <Building2 className="w-4 h-4 mr-2" />
          Nova Agência
        </Button>
      </div>

      <div className="bg-white shadow-sm rounded-lg overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Agência
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Responsável
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Contato
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Plano
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Último Pagamento
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Próximo Pagamento
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Ações
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {agencies.map((agency) => (
                <tr key={agency.id}>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900">
                      {agency.name}
                    </div>
                    <div className="text-sm text-gray-500">
                      <a
                        href={agency.website}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center hover:text-blue-600"
                      >
                        {agency.website}
                        <ExternalLink className="w-3 h-3 ml-1" />
                      </a>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900">{agency.responsible}</div>
                    <div className="text-sm text-gray-500">{agency.username}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900">{agency.email}</div>
                    <div className="text-sm text-gray-500">{agency.whatsapp}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getPlanColor(agency.plan)}`}>
                      {getPlanLabel(agency.plan)}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center text-sm text-gray-500">
                      <Calendar className="w-4 h-4 mr-1" />
                      {agency.lastPaymentDate?.toLocaleDateString('pt-BR')}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center text-sm text-gray-500">
                      <Calendar className="w-4 h-4 mr-1" />
                      {agency.nextPaymentDate?.toLocaleDateString('pt-BR')}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input
                        type="checkbox"
                        className="sr-only peer"
                        checked={agency.isActive}
                        onChange={() => handleToggleAccess(agency.id)}
                      />
                      <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                    </label>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <Button 
                      variant="secondary" 
                      size="sm" 
                      className="mr-2"
                      onClick={() => handleEditAgency(agency.id)}
                    >
                      <Edit2 className="w-4 h-4" />
                    </Button>
                    <Button variant="outline" size="sm">
                      <Trash2 className="w-4 h-4 text-red-500" />
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};