export interface Payment {
  id: string;
  agencyId: string;
  planId: number;
  amount: number;
  status: 'pending' | 'paid' | 'failed';
  dueDate: Date;
  paidAt?: Date;
}

export interface AgencySubscription {
  id: string;
  agencyId: string;
  planId: number;
  status: 'active' | 'suspended' | 'cancelled';
  startDate: Date;
  nextBillingDate: Date;
}