import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Users, Building2, Package, Settings } from 'lucide-react';

interface SidebarItemProps {
  icon: React.ReactNode;
  label: string;
  to: string;
  active: boolean;
}

const SidebarItem: React.FC<SidebarItemProps> = ({ icon, label, to, active }) => (
  <Link
    to={to}
    className={`flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors ${
      active
        ? 'bg-blue-50 text-blue-700'
        : 'text-gray-700 hover:bg-gray-50'
    }`}
  >
    {icon}
    <span className="font-medium">{label}</span>
  </Link>
);

export const DashboardLayout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const location = useLocation();

  return (
    <div className="flex h-screen bg-gray-50">
      {/* Sidebar */}
      <div className="w-64 bg-white shadow-sm border-r">
        <div className="p-4">
          <h2 className="text-xl font-bold text-blue-600">Hub.Nexus</h2>
        </div>
        <nav className="mt-4 px-2 space-y-1">
          <SidebarItem
            icon={<Users className="w-5 h-5" />}
            label="Clientes"
            to="/dashboard/clientes"
            active={location.pathname === '/dashboard/clientes'}
          />
          <SidebarItem
            icon={<Building2 className="w-5 h-5" />}
            label="Agências"
            to="/dashboard/agencias"
            active={location.pathname === '/dashboard/agencias'}
          />
          <SidebarItem
            icon={<Package className="w-5 h-5" />}
            label="Planos"
            to="/dashboard/planos"
            active={location.pathname === '/dashboard/planos'}
          />
          <SidebarItem
            icon={<Settings className="w-5 h-5" />}
            label="Configurações"
            to="/dashboard/configuracoes"
            active={location.pathname === '/dashboard/configuracoes'}
          />
        </nav>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-auto">
        <main className="p-6">{children}</main>
      </div>
    </div>
  );
};