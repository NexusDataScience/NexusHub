import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { User, Mail, Phone } from 'lucide-react';
import { Input } from '../../components/ui/Input';
import { Button } from '../../components/ui/Button';
import type { ClientFormData } from '../../types/client';

export const NewClientPage: React.FC = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState<ClientFormData>({
    name: '',
    email: '',
    phone: '',
    status: 'active',
    campaigns: {
      google: 0,
      meta: 0
    }
  });

  return (
    <div className="max-w-2xl mx-auto">
      <div className="mb-8">
        <h1 className="text-2xl font-semibold text-gray-900">Novo Cliente</h1>
        <p className="text-sm text-gray-500 mt-1">
          Cadastre um novo cliente para sua agência
        </p>
      </div>

      <form 
        name="client-registration" 
        method="POST" 
        data-netlify="true"
        className="bg-white shadow-sm rounded-lg p-6 space-y-6"
      >
        <input type="hidden" name="form-name" value="client-registration" />

        <Input
          label="Nome do Cliente"
          name="client-name"
          icon={<User className="w-5 h-5 text-gray-400" />}
          required
          value={formData.name}
          onChange={(e) => setFormData({ ...formData, name: e.target.value })}
        />

        <Input
          label="Email"
          name="email"
          type="email"
          icon={<Mail className="w-5 h-5 text-gray-400" />}
          required
          value={formData.email}
          onChange={(e) => setFormData({ ...formData, email: e.target.value })}
        />

        <Input
          label="Telefone"
          name="phone"
          type="tel"
          icon={<Phone className="w-5 h-5 text-gray-400" />}
          required
          value={formData.phone}
          onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
        />

        <div className="space-y-1">
          <label className="block text-sm font-medium text-gray-700">
            Campanhas Iniciais
          </label>
          <div className="grid grid-cols-2 gap-4">
            <Input
              label="Google Ads"
              name="google-campaigns"
              type="number"
              min="0"
              value={formData.campaigns.google}
              onChange={(e) => setFormData({
                ...formData,
                campaigns: {
                  ...formData.campaigns,
                  google: parseInt(e.target.value) || 0
                }
              })}
            />
            <Input
              label="Meta Ads"
              name="meta-campaigns"
              type="number"
              min="0"
              value={formData.campaigns.meta}
              onChange={(e) => setFormData({
                ...formData,
                campaigns: {
                  ...formData.campaigns,
                  meta: parseInt(e.target.value) || 0
                }
              })}
            />
          </div>
        </div>

        <div className="pt-4">
          <Button type="submit" className="w-full">
            Cadastrar Cliente
          </Button>
        </div>
      </form>
    </div>
  );
};