export type Plan = 1 | 2 | 3;

export interface Agency {
  id: string;
  name: string;
  website: string;
  responsible: string;
  username: string;
  email: string;
  whatsapp: string;
  plan: Plan;
  createdAt: Date;
  isActive: boolean;
  lastPaymentDate?: Date;
  nextPaymentDate?: Date;
}

export type AgencyFormData = Omit<Agency, 'id' | 'createdAt'> & {
  password: string;
};