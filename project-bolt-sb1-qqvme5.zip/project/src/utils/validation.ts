export const validateDomain = (website: string): string => {
  // Remove http://, https://, and www. if present
  let domain = website.toLowerCase()
    .replace(/^https?:\/\//, '')
    .replace(/^www\./, '');

  // Remove any trailing path or query parameters
  domain = domain.split('/')[0];

  // Basic domain validation
  const domainRegex = /^[a-zA-Z0-9][a-zA-Z0-9-]{1,61}[a-zA-Z0-9]\.[a-zA-Z]{2,}$/;
  if (!domainRegex.test(domain)) {
    throw new Error('Domínio inválido');
  }

  return domain;
};