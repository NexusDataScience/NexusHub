import React, { useState } from 'react';
import { Building2, Globe, Mail, Phone, User } from 'lucide-react';
import { Input } from '../components/ui/Input';
import { Button } from '../components/ui/Button';
import type { AgencyFormData } from '../types/agency';

export const AgencyRegistration: React.FC = () => {
  const [formData, setFormData] = useState<AgencyFormData>({
    name: '',
    website: '',
    responsible: '',
    username: '',
    password: '',
    email: '',
    whatsapp: '',
    plan: 1
  });

  const formatWhatsApp = (value: string) => {
    const numbers = value.replace(/\D/g, '');
    if (numbers.length <= 11) {
      return numbers
        .replace(/(\d{2})/, '($1) ')
        .replace(/(\d{5})/, '$1-')
        .replace(/(-\d{4})\d+?$/, '$1');
    }
    return value;
  };

  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md mx-auto">
        <div className="text-center">
          <h2 className="mt-6 text-3xl font-bold text-gray-900">
            Cadastre sua Agência
          </h2>
          <p className="mt-2 text-sm text-gray-600">
            Junte-se ao Hub.Nexus e gerencie seus clientes de forma eficiente
          </p>
        </div>

        <form 
          name="agency-registration" 
          method="POST" 
          data-netlify="true"
          className="mt-8 space-y-6"
          netlify-honeypot="bot-field"
        >
          <input type="hidden" name="form-name" value="agency-registration" />
          <p className="hidden">
            <label>
              Don't fill this out if you're human: <input name="bot-field" />
            </label>
          </p>
          
          <div className="rounded-md shadow-sm space-y-4">
            <Input
              label="Nome da Agência"
              name="agency-name"
              icon={<Building2 className="w-5 h-5 text-gray-400" />}
              type="text"
              required
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            />

            <Input
              label="Website"
              name="website"
              icon={<Globe className="w-5 h-5 text-gray-400" />}
              type="text"
              required
              value={formData.website}
              onChange={(e) => setFormData({ ...formData, website: e.target.value })}
            />

            <Input
              label="Responsável"
              name="responsible"
              icon={<User className="w-5 h-5 text-gray-400" />}
              type="text"
              required
              value={formData.responsible}
              onChange={(e) => setFormData({ ...formData, responsible: e.target.value })}
            />

            <Input
              label="Usuário"
              name="username"
              type="text"
              required
              value={formData.username}
              onChange={(e) => setFormData({ ...formData, username: e.target.value })}
            />

            <Input
              label="Senha"
              name="password"
              type="password"
              required
              value={formData.password}
              onChange={(e) => setFormData({ ...formData, password: e.target.value })}
            />

            <Input
              label="Email"
              name="email"
              icon={<Mail className="w-5 h-5 text-gray-400" />}
              type="email"
              required
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
            />

            <Input
              label="WhatsApp"
              name="whatsapp"
              icon={<Phone className="w-5 h-5 text-gray-400" />}
              type="tel"
              required
              value={formData.whatsapp}
              onChange={(e) => setFormData({ ...formData, whatsapp: formatWhatsApp(e.target.value) })}
            />

            <div className="space-y-1">
              <label className="block text-sm font-medium text-gray-700">
                Selecione o Plano
              </label>
              <select
                name="plan"
                className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm rounded-md"
                value={formData.plan}
                onChange={(e) => setFormData({ ...formData, plan: Number(e.target.value) as 1 | 2 | 3 })}
              >
                <option value={1}>Plano Básico</option>
                <option value={2}>Plano Profissional</option>
                <option value={3}>Plano Enterprise</option>
              </select>
            </div>
          </div>

          <Button type="submit" className="w-full">
            Cadastrar Agência
          </Button>
        </form>
      </div>
    </div>
  );
};