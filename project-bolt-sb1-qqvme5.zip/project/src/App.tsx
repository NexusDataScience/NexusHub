import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Navbar } from './components/Navbar';
import { HomePage } from './pages/HomePage';
import { LoginPage } from './pages/LoginPage';
import { DashboardLayout } from './components/DashboardLayout';
import { ClientesPage } from './pages/dashboard/ClientesPage';
import { AgenciasPage } from './pages/dashboard/AgenciasPage';
import { AgencyDetailsPage } from './pages/dashboard/AgencyDetailsPage';
import { PlanosPage } from './pages/dashboard/PlanosPage';
import { ConfiguracoesPage } from './pages/dashboard/ConfiguracoesPage';
import { AgencyRegistration } from './pages/AgencyRegistration';
import { BlockedAccessPage } from './pages/BlockedAccessPage';
import { NewClientPage } from './pages/dashboard/NewClientPage';
import { NewAgencyPage } from './pages/dashboard/NewAgencyPage';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route
          path="/"
          element={
            <>
              <Navbar />
              <HomePage />
            </>
          }
        />
        <Route path="/login" element={<LoginPage />} />
        <Route path="/cadastro" element={<AgencyRegistration />} />
        <Route path="/blocked" element={<BlockedAccessPage />} />
        
        {/* Dashboard Routes */}
        <Route
          path="/dashboard"
          element={
            <DashboardLayout>
              <Navigate to="/dashboard/clientes" replace />
            </DashboardLayout>
          }
        />
        <Route
          path="/dashboard/clientes"
          element={
            <DashboardLayout>
              <ClientesPage />
            </DashboardLayout>
          }
        />
        <Route
          path="/dashboard/clientes/novo"
          element={
            <DashboardLayout>
              <NewClientPage />
            </DashboardLayout>
          }
        />
        <Route
          path="/dashboard/agencias"
          element={
            <DashboardLayout>
              <AgenciasPage />
            </DashboardLayout>
          }
        />
        <Route
          path="/dashboard/agencias/nova"
          element={
            <DashboardLayout>
              <NewAgencyPage />
            </DashboardLayout>
          }
        />
        <Route
          path="/dashboard/agencias/:id"
          element={
            <DashboardLayout>
              <AgencyDetailsPage />
            </DashboardLayout>
          }
        />
        <Route
          path="/dashboard/planos"
          element={
            <DashboardLayout>
              <PlanosPage />
            </DashboardLayout>
          }
        />
        <Route
          path="/dashboard/configuracoes"
          element={
            <DashboardLayout>
              <ConfiguracoesPage />
            </DashboardLayout>
          }
        />
      </Routes>
    </BrowserRouter>
  );
}

export default App;