import React from 'react';
import { AlertCircle } from 'lucide-react';
import { Button } from '../components/ui/Button';

export const BlockedAccessPage: React.FC = () => {
  return (
    <div className="min-h-screen bg-gray-50 flex flex-col justify-center items-center px-4">
      <div className="max-w-md w-full bg-white rounded-lg shadow-sm p-8 text-center">
        <div className="flex justify-center mb-4">
          <AlertCircle className="w-16 h-16 text-red-500" />
        </div>
        <h1 className="text-2xl font-bold text-gray-900 mb-4">
          Recursos Bloqueados
        </h1>
        <p className="text-gray-600 mb-6">
          Seu acesso está temporariamente suspenso. Por favor, entre em contato com nosso departamento financeiro para regularizar sua situação.
        </p>
        <div className="space-y-4">
          <Button
            variant="outline"
            className="w-full"
            onClick={() => window.location.href = 'mailto:financeiro@hub.nexus.com.br'}
          >
            Contatar Departamento Financeiro
          </Button>
          <p className="text-sm text-gray-500">
            Email: financeiro@hub.nexus.com.br<br />
            WhatsApp: (11) 99999-9999
          </p>
        </div>
      </div>
    </div>
  );
};