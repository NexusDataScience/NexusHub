import React from 'react';
import { Calendar, CreditCard, AlertCircle } from 'lucide-react';
import { Button } from '../../components/ui/Button';
import type { Payment } from '../../types/payment';

export const AgencyProfilePage: React.FC = () => {
  // Mock data - replace with actual data
  const agency = {
    id: '1',
    name: 'Digital Marketing Pro',
    website: 'https://dmpro.com',
    responsible: 'John Doe',
    email: 'contact@dmpro.com',
    whatsapp: '+1234567890',
    plan: 2,
    status: 'active' as const,
  };

  const payments: Payment[] = [
    {
      id: '1',
      agencyId: '1',
      planId: 2,
      amount: 499,
      status: 'paid',
      dueDate: new Date('2024-03-01'),
      paidAt: new Date('2024-02-28'),
    },
    {
      id: '2',
      agencyId: '1',
      planId: 2,
      amount: 499,
      status: 'pending',
      dueDate: new Date('2024-04-01'),
    },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div className="space-y-6">
        {/* Agency Status */}
        <div className="bg-white shadow-sm rounded-lg p-6">
          <div className="flex justify-between items-start">
            <div>
              <h2 className="text-2xl font-semibold text-gray-900">{agency.name}</h2>
              <p className="text-sm text-gray-500 mt-1">{agency.website}</p>
            </div>
            <div className={`px-3 py-1 rounded-full text-sm font-medium ${
              agency.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
            }`}>
              {agency.status === 'active' ? 'Ativo' : 'Suspenso'}
            </div>
          </div>

          <div className="mt-6 grid grid-cols-1 gap-6 sm:grid-cols-2">
            <div>
              <h3 className="text-lg font-medium text-gray-900">Informações de Contato</h3>
              <dl className="mt-4 space-y-4">
                <div>
                  <dt className="text-sm font-medium text-gray-500">Responsável</dt>
                  <dd className="mt-1 text-sm text-gray-900">{agency.responsible}</dd>
                </div>
                <div>
                  <dt className="text-sm font-medium text-gray-500">Email</dt>
                  <dd className="mt-1 text-sm text-gray-900">{agency.email}</dd>
                </div>
                <div>
                  <dt className="text-sm font-medium text-gray-500">WhatsApp</dt>
                  <dd className="mt-1 text-sm text-gray-900">{agency.whatsapp}</dd>
                </div>
              </dl>
            </div>

            <div>
              <h3 className="text-lg font-medium text-gray-900">Plano Atual</h3>
              <div className="mt-4 p-4 bg-gray-50 rounded-lg">
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium text-gray-900">Plano Agência</span>
                  <span className="text-sm text-gray-500">R$499/mês</span>
                </div>
                <Button className="mt-4 w-full">Alterar Plano</Button>
              </div>
            </div>
          </div>
        </div>

        {/* Payment History */}
        <div className="bg-white shadow-sm rounded-lg p-6">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Histórico de Pagamentos</h3>
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead>
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Data de Vencimento
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Valor
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Status
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Data do Pagamento
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {payments.map((payment) => (
                  <tr key={payment.id}>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      <div className="flex items-center">
                        <Calendar className="w-4 h-4 text-gray-400 mr-2" />
                        {payment.dueDate.toLocaleDateString()}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      <div className="flex items-center">
                        <CreditCard className="w-4 h-4 text-gray-400 mr-2" />
                        R${payment.amount}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                        payment.status === 'paid'
                          ? 'bg-green-100 text-green-800'
                          : payment.status === 'pending'
                          ? 'bg-yellow-100 text-yellow-800'
                          : 'bg-red-100 text-red-800'
                      }`}>
                        {payment.status === 'paid' ? 'Pago' : payment.status === 'pending' ? 'Pendente' : 'Falhou'}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {payment.paidAt ? payment.paidAt.toLocaleDateString() : '-'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Access Control */}
        <div className="bg-white shadow-sm rounded-lg p-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-lg font-medium text-gray-900">Controle de Acesso</h3>
              <p className="text-sm text-gray-500 mt-1">Gerencie o acesso da agência ao sistema</p>
            </div>
            <Button variant="outline" className="text-red-600 border-red-600 hover:bg-red-50">
              <AlertCircle className="w-4 h-4 mr-2" />
              Suspender Acesso
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};