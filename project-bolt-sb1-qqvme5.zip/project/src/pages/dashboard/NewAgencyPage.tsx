import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Building2, Globe, Mail, Phone, User } from 'lucide-react';
import { Input } from '../../components/ui/Input';
import { Button } from '../../components/ui/Button';
import { validateDomain } from '../../utils/validation';
import type { AgencyFormData } from '../../types/agency';

export const NewAgencyPage: React.FC = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState<AgencyFormData>({
    name: '',
    website: '',
    responsible: '',
    username: '',
    password: '',
    email: '',
    whatsapp: '',
    plan: 1,
    isActive: true
  });

  const [errors, setErrors] = useState<Partial<Record<keyof AgencyFormData, string>>>({});

  const validateForm = () => {
    const newErrors: Partial<Record<keyof AgencyFormData, string>> = {};

    if (!formData.name.trim()) {
      newErrors.name = 'Nome é obrigatório';
    }

    if (!formData.website.trim()) {
      newErrors.website = 'Website é obrigatório';
    } else {
      try {
        validateDomain(formData.website);
      } catch (error) {
        newErrors.website = 'Website inválido. Use apenas o domínio (ex: seusite.com.br)';
      }
    }

    if (!formData.responsible.trim()) {
      newErrors.responsible = 'Responsável é obrigatório';
    }

    if (!formData.username.trim()) {
      newErrors.username = 'Usuário é obrigatório';
    }

    if (!formData.password || formData.password.length < 6) {
      newErrors.password = 'Senha deve ter no mínimo 6 caracteres';
    }

    if (!formData.email.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'Email inválido';
    }

    if (!formData.whatsapp.trim() || !/^\(\d{2}\)\s\d{5}-\d{4}$/.test(formData.whatsapp)) {
      newErrors.whatsapp = 'WhatsApp inválido. Use o formato (99) 99999-9999';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateForm()) {
      return;
    }

    try {
      // Format the website to store only the domain
      const formattedData = {
        ...formData,
        website: validateDomain(formData.website)
      };

      // TODO: Send to API
      console.log('New agency:', formattedData);
      
      // Redirect on success
      navigate('/dashboard/agencias');
    } catch (error) {
      console.error('Error creating agency:', error);
      setErrors(prev => ({
        ...prev,
        submit: 'Erro ao criar agência. Tente novamente.'
      }));
    }
  };

  const formatWhatsApp = (value: string) => {
    // Remove all non-digits
    const numbers = value.replace(/\D/g, '');
    
    // Format as (99) 99999-9999
    if (numbers.length <= 11) {
      return numbers
        .replace(/(\d{2})/, '($1) ')
        .replace(/(\d{5})/, '$1-')
        .replace(/(-\d{4})\d+?$/, '$1');
    }
    return value;
  };

  return (
    <div className="max-w-2xl mx-auto">
      <div className="mb-8">
        <h1 className="text-2xl font-semibold text-gray-900">Nova Agência</h1>
        <p className="text-sm text-gray-500 mt-1">
          Cadastre uma nova agência no sistema
        </p>
      </div>

      <form onSubmit={handleSubmit} className="bg-white shadow-sm rounded-lg p-6 space-y-6">
        <Input
          label="Nome da Agência"
          icon={<Building2 className="w-5 h-5 text-gray-400" />}
          required
          value={formData.name}
          onChange={(e) => setFormData({ ...formData, name: e.target.value })}
          error={errors.name}
        />

        <Input
          label="Website (apenas o domínio)"
          placeholder="exemplo.com.br"
          icon={<Globe className="w-5 h-5 text-gray-400" />}
          required
          value={formData.website}
          onChange={(e) => setFormData({ ...formData, website: e.target.value })}
          error={errors.website}
        />

        <Input
          label="Responsável"
          icon={<User className="w-5 h-5 text-gray-400" />}
          required
          value={formData.responsible}
          onChange={(e) => setFormData({ ...formData, responsible: e.target.value })}
          error={errors.responsible}
        />

        <Input
          label="Usuário"
          required
          value={formData.username}
          onChange={(e) => setFormData({ ...formData, username: e.target.value })}
          error={errors.username}
        />

        <Input
          label="Senha"
          type="password"
          required
          value={formData.password}
          onChange={(e) => setFormData({ ...formData, password: e.target.value })}
          error={errors.password}
        />

        <Input
          label="Email"
          type="email"
          icon={<Mail className="w-5 h-5 text-gray-400" />}
          required
          value={formData.email}
          onChange={(e) => setFormData({ ...formData, email: e.target.value })}
          error={errors.email}
        />

        <Input
          label="WhatsApp"
          type="tel"
          placeholder="(99) 99999-9999"
          icon={<Phone className="w-5 h-5 text-gray-400" />}
          required
          value={formData.whatsapp}
          onChange={(e) => setFormData({ ...formData, whatsapp: formatWhatsApp(e.target.value) })}
          error={errors.whatsapp}
        />

        <div className="space-y-1">
          <label className="block text-sm font-medium text-gray-700">
            Plano
          </label>
          <select
            className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm rounded-md"
            value={formData.plan}
            onChange={(e) => setFormData({ ...formData, plan: Number(e.target.value) as 1 | 2 | 3 })}
          >
            <option value={1}>Iniciante (Básico)</option>
            <option value={2}>Agência</option>
            <option value={3}>Super Agência</option>
          </select>
        </div>

        {errors.submit && (
          <p className="text-sm text-red-600">{errors.submit}</p>
        )}

        <div className="pt-4">
          <Button type="submit" className="w-full">
            Cadastrar Agência
          </Button>
        </div>
      </form>
    </div>
  );
};