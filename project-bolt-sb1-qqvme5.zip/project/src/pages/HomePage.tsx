import React from 'react';
import { ArrowRight, BarChart2, Target, TrendingUp } from 'lucide-react';
import { Button } from '../components/ui/Button';

export const HomePage: React.FC = () => {
  return (
    <div className="bg-white">
      {/* Hero Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center">
          <h1 className="text-4xl font-bold text-gray-900 sm:text-5xl md:text-6xl">
            Transforme Dados em Decisões Acertadas
          </h1>
          <p className="mt-3 max-w-md mx-auto text-base text-gray-500 sm:text-lg md:mt-5 md:text-xl md:max-w-3xl">
            Com o Hub.Nexus, você descobre exatamente onde investir e identifica o retorno real das suas campanhas de Google Ads e Meta Ads.
          </p>
        </div>
      </div>

      {/* Features Section */}
      <div className="bg-gray-50 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-3xl font-bold text-gray-900">
              Saiba o que realmente está funcionando
            </h2>
            <div className="mt-10 grid grid-cols-1 gap-10 sm:grid-cols-3">
              <div className="bg-white p-6 rounded-lg shadow-sm">
                <div className="text-blue-600 mb-4">
                  <TrendingUp className="w-8 h-8 mx-auto" />
                </div>
                <p className="text-gray-700">💡 Quais criativos estão convertendo?</p>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-sm">
                <div className="text-blue-600 mb-4">
                  <Target className="w-8 h-8 mx-auto" />
                </div>
                <p className="text-gray-700">🔑 Quais palavras-chave estão gerando vendas?</p>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-sm">
                <div className="text-blue-600 mb-4">
                  <BarChart2 className="w-8 h-8 mx-auto" />
                </div>
                <p className="text-gray-700">📊 Quais campanhas trazem o melhor ROI?</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Benefits Section */}
      <div className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">
            Por que escolher o Hub.Nexus?
          </h2>
          <div className="grid grid-cols-1 gap-8 sm:grid-cols-3">
            <div className="text-center">
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Análise em Tempo Real</h3>
              <p className="text-gray-600">Veja o desempenho das suas campanhas de forma clara e rápida.</p>
            </div>
            <div className="text-center">
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Foco no ROI</h3>
              <p className="text-gray-600">Descubra o que está trazendo resultados e maximize o retorno sobre o investimento.</p>
            </div>
            <div className="text-center">
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Insights Acionáveis</h3>
              <p className="text-gray-600">Encontre oportunidades para otimizar cada detalhe da sua estratégia.</p>
            </div>
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="bg-blue-600">
        <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-3xl font-bold text-white mb-8">
              Invista com Segurança e Inteligência
            </h2>
            <p className="text-xl text-blue-100 mb-8">
              Pare de desperdiçar orçamento em campanhas que não performam. Com o Hub.Nexus, você tem o controle total dos seus dados e direciona cada centavo para o que realmente funciona.
            </p>
            <Button size="lg" className="bg-white text-blue-600 hover:bg-blue-50">
              Solicite uma demonstração gratuita <ArrowRight className="w-5 h-5 ml-2 inline" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};